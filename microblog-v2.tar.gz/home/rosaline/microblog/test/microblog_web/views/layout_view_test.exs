defmodule MicroblogWeb.LayoutViewTest do
  use MicroblogWeb.ConnCase, async: true
end
